FT.manifest({
	"filename":"main.html",
	"width":300,
	"height":250,
	"clickTagCount":1,
	"instantAds":[
		{"name":"textVar", "type":"text", "default":"XXX XXX XXXXX XXXX XXXXXXX"}
	]
});